package Solution;

import Instances.InstanceFetcher;
import Resource.Package.BackPackage;
import Resource.Package.GoPackage;
import java.util.*;
public class PackageSet {
	HashMap<Integer,HashSet<GoPackage>> go_pack; //key=目的地的ID，value=送往该目的地的快递集合
	HashMap<Integer,HashSet<BackPackage>> back_pack;
	public PackageSet(InstanceFetcher ins) {
		go_pack = new HashMap<>();//存放送去包裹
		for (int i = 0; i < ins.gopacknum; i++) {
			int stationId=ins.gopack[i].destination;
            if (go_pack.containsKey(stationId)) {
                go_pack.get(stationId).add(ins.gopack[i]);
            }else {
                HashSet<GoPackage> packset = new HashSet<>();
                packset.add(ins.gopack[i]);
                go_pack.put(stationId, packset);
            }
		}
		//ins.backpack处理
		back_pack = new HashMap<>();//存放返回包裹
        for (int j = 0; j < ins.backpacknum; j++) {
            int stationid=ins.backpack[j].destination;
            if (back_pack.containsKey(stationid)) {
                back_pack.get(stationid).add(ins.backpack[j]);
            } else {
                HashSet<BackPackage> packset = new HashSet<>();
                packset.add(ins.backpack[j]);
                back_pack.put(stationid, packset);
            }
        }
	}

	//从HashSet中获取对应id的包裹
	public HashSet<GoPackage> getGo_Package(int stationid) {
		HashSet<GoPackage> set = null;
		if(go_pack.get(stationid) != null) {
			set = go_pack.get(stationid);
		}
		return set;
	}

	//从HashSet中获取对应id的包裹
	public HashSet<BackPackage> getBack_Package(int stationid) {
		HashSet<BackPackage> set = null;
		if(back_pack.get(stationid) != null) {
			set = back_pack.get(stationid);
		}
		return set;
	}

	//按照id从小到大排序
//	public HashMap<Integer,HashSet<GoPackage>> sortByweight(HashMap){
//		PackageSet set = new PackageSet(ins);
//		for(int i = 1; i <= ins.psnum; i++) {
//			HashSet<GoPackage> hashSet = set.getGo_Package(i);
//			if(hashSet==null) {
//				System.out.println("there no package send to destination:" + i);
//			} else {
//				//对HashSet进行排序
//				// 办法 1，HashSet转成List进行排序 ，方法2，转成TreeSet进行排序
//				ArrayList<GoPackage> list = new ArrayList<>(hashSet);
//				Collections.sort(list, new Comparator<GoPackage>() {
//					@Override
//					public int compare(GoPackage p1, GoPackage p2) {
//						return p1.weight - p2.weight;
//					}
//				});
//			}
//		}
//		return set.go_pack;
//	}

	public static void main(String[] args) {
		InstanceFetcher ins= new InstanceFetcher(1000,10,500000,0.2,10,0);

//		System.out.println(ins.backpacknum);
//		System.out.println(ins.backpack[92].weight);
		PackageSet set=new PackageSet(ins);

		//按照key=stationid遍历送去的包裹
//		HashMap<Integer,HashSet<GoPackage>> go=set.go_pack;
//		Integer[] gokeys=go.keySet().toArray(new Integer[] {});
//		for (Integer key:gokeys){
//			HashSet<GoPackage> goset=go.get(key);
//			for (GoPackage i:goset){
//				System.out.print(i.weight+" ");
//			}
//		}
//		System.out.println();
//
//		//按照key=stationid遍历回来的包裹
//		HashMap<Integer,HashSet<BackPackage>> back=set.back_pack;
//		Integer[] backkeys=back.keySet().toArray(new Integer[] {});
//		for (Integer key:backkeys){
//			HashSet<BackPackage> backset=back.get(key);
//			for (BackPackage i:backset){
//				System.out.print(i.weight+" ");
//			}
//		}
	}
}
