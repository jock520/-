package Solution;

import java.util.ArrayList;
import java.util.List;

public class Assignment {
	public long StartTime=0;
	public List<Integer> SingleTrip;//单趟存放的有哪些信息
	public Assignment(){
		this.SingleTrip=new ArrayList<>();
	}
}
