package Solution;
//
import Resource.Package.GoPackage;
import Resource.UAV.UAV;

import java.util.ArrayList;
import java.util.Map;

//import Instances.InstanceFetcher;
//import Model.PackageSet;
//
///**
// * @author ：cavan
// * @date ：2019/4/20 19:35
// */
////安排计划表
public class Schedule {
    public static final long BeginTime=0;
    public static final long CSTime=20;
    public static final long PSTime=10;
    public ArrayList<UAVAssignments> Solution;
    public Schedule(){
        this.Solution=new ArrayList<>();


    }
//
//    public static void change(){
//
//    }
//    public static void rollback() {
//
//    }
//    public static void rollbackPacks(){
//
//    }
//    public static Schedule clonePacks(){
//        Schedule res=new Schedule();
//
//        return res;
//    }
//    public static void Method(PackageSet set, InstanceFetcher inf){
//
//    }
}
