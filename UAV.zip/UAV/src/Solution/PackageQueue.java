//package Model;
//
//import Instances.InstanceFetcher;
//
//import java.util.*;
//
///**
// * @author ：cavan
// * @date ：2019/4/26 13:45
// */
//public class PackageQueue {
//    public class PQueue {
//        public List<Integer> set=new ArrayList<>();
//    }
//    public PQueue[] go_QSet;
//    public PQueue[] back_QSet;
//    //初始化
//    public PackageQueue(InstanceFetcher inf){
//        this.go_QSet=new PQueue[inf.m.PSNum];
//        this.back_QSet=new PQueue[inf.m.PSNum];
//        for(int i=0; i<inf.m.PSNum; i++){
//            go_QSet[i]=new PQueue();
//            back_QSet[i]=new PQueue();
//        }
//        for (int j=0;j<inf.PackN;j++){
//            if (inf.pack[j].state==0){
//                go_QSet[inf.pack[j].StationID-1].set.add(j);
//            }else {
//                back_QSet[inf.pack[j].StationID-1].set.add(j);
//            }
//        }
//    }
//
//    public void SortByWeight(InstanceFetcher inf,PQueue[] pq){
//        for(int i=0; i<inf.m.PSNum; i++) {
//            for(int j=0; j<pq[i].set.size()-1; j++) {
//                for(int k=j+1; k<pq[i].set.size(); k++) {
//                    if(inf.pack[pq[i].set.get(j)].Weight<inf.pack[pq[i].set.get(k)].Weight) {
//                        int temp=pq[i].set.get(j);
//                        pq[i].set.set(j, pq[i].set.get(k));
//                        pq[i].set.set(k, temp);
//                    }
//                }
//            }
//		    System.out.println("\nPQueue:");
//			for(int j=0; j<go_QSet[i].set.size(); j++) {
//				System.out.print(go_QSet[i].set.get(j)+" ");
//			}
//            System.out.println();
//		}
//    }
//
////    public static void main(String[] args) {
////        String Map_dir = "instance/Map/" + "Map_" + 1000 + "_" + 10 + "_"+0+".txt";
////		String Package_dir = "instance/Packages/" + "Package_" + 10 + "_" + 500000 + "_"+0.2+"_"+0+".txt";
////		InstanceFetcher inf=new InstanceFetcher(Map_dir,Package_dir,10,0);
////        PackageQueue p=new PackageQueue(inf);
////        p.SortByWeight(inf,p.go_QSet);
////    }
//}
