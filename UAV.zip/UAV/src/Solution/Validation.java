package Solution;

import Instances.InstanceFetcher;
import java.util.Random;

/**
 * @author ：cavan
 * @date ：2019/4/26 18:09
 */
public class Validation {


}
