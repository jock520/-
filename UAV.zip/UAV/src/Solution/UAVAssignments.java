package Solution;

import java.util.ArrayList;
//
public class UAVAssignments {
	public long FinishTime=0;
	public ArrayList<Assignment> MultiTrip;
	public UAVAssignments() {
		this.MultiTrip=new ArrayList<>();
	}
}
