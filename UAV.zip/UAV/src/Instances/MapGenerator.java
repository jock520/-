package Instances;

import Resource.Map.CenterStation;
import Resource.Map.Map;
import Resource.Map.PostStation;
import Tool.textWriter;
import java.util.Random;
import static Instances.Parameters.*;

public class MapGenerator {
    public Map m;
    private static final int minDistance=300;
    private String str;

    //	dir文件目录     radius：区域半径。	psnum：产生poststation的个数
    public MapGenerator(String dir,int radius,int psnum) {
        //确定各个参数的数值
        //初始化cs,ps
        CenterStation cs=new CenterStation(0,radius,radius);
        PostStation[] ps=new PostStation[psnum];
        int xx, yy,times=0;
        for(int i=0; i<psnum; i++) {
            boolean flag;
            do {
                flag=false;
                times++;
                xx=(new Random().nextInt())%(radius+1)+radius;
                yy=(new Random().nextInt())%(radius+1)+radius;
                //当前点和已知点的距离应大于minDistance
                for(int j=0; j<i; j++) {
                    if(Math.sqrt((xx-ps[j].x)*(xx-ps[j].x)+ (yy-ps[j].y)*(yy-ps[j].y))<minDistance) {
                        flag=true;
                        break;
                    }
                }
                if(Math.sqrt((xx-cs.x)*(xx-cs.x)+(yy-cs.y)*(yy-cs.y)) <minDistance) flag=true;
            }while(times<10000&&(flag||Math.sqrt(Math.pow(xx-radius,2)+Math.pow(yy-radius,2))>radius));
            ps[i]=new PostStation(i+1,xx,yy);
        }
        m=new Map(psnum,radius,cs,ps);
        //
        str=m.cs.id+"\t"+m.cs.x+"\t"+m.cs.y+"\r\n";
        for(int i=0; i<psnum; i++){
            str=str+(i+1)+"\t"+m.ps[i].x+"\t"+m.ps[i].y+"\r\n";
        }
        new textWriter(dir,str);
    }
    public static void main(String[] args) {
        for (int i=0;i<radius.length;i++){
            for (int j=0;j<psNum.length;j++){
//                for (int k=0;k<10;k++){
                    String dir="instance/Map/" + "Map_" +radius[i] + "_" + psNum[j] +".txt";
                    MapGenerator mapGenerator=new MapGenerator(dir,radius[i],psNum[j]);
//                }
            }
        }
    }
}


