package Instances;

/**
 * @author ：cavan
 * @date ：2019/5/5 13:50
 */
public class Parameters {

    //UAV的参数，数量及类型
    public static int[] uavNum={10,20,30};
    public static int[] uavType={0,1,2};

    //Package的参数
    public static int[] weight={500000,1000000,2000000};
    public static double[] proportion={0.2,0.6,1};

    //Map的参数
    public static int[] radius={1000,2500,5000};
    public static int[] psNum={10,20,30};
}
