package Instances;

import java.io.*;
import java.util.HashMap;
import Resource.Map.CenterStation;
import Resource.Map.Map;
import Resource.Map.PostStation;
import Resource.Package.BackPackage;
import Resource.Package.GoPackage;
import Resource.UAV.UAV;
import static Instances.Parameters.*;

/**
 * @author ：cavan
 * @date ：2019/4/17 16:43
 */
//将指定的位置的用例文件读入参数中
public class InstanceFetcher{
    //
    public static int psNum;
    public static int uavNum;

    //
    public static int weight;
    //
    public Map m;
    public GoPackage[] gopack;
    public BackPackage[] backpack;
    public UAV[] uavs;

    //
    public double[][] distance;//初始化距离矩阵
    public HashMap<Integer, GoPackage> go_packMap;
    public HashMap<Integer, BackPackage> back_packMap;

    //
    public int gopacknum;//用于统计包裹的数量
    public int backpacknum;
    public int uavnum;
    public int psnum;
    //参数依次为地图、包裹的测试用例的位置、UAV的数量、UAV的类型
    public InstanceFetcher(int radius,int psNum,int weight,double proportion,int uavNum,int uavType){
        this.psNum=psNum;
        this.uavNum=uavNum;

        String Map_dir="instance/Map/" + "Map_" + radius + "_" + psNum +".txt";
        String UAV_dir="instance/UAV/" + "UAV_" + uavNum + "_" + uavType +".txt";
        String Package_dir="instance/Packages/" + "Package_" + psNum + "_" + weight + "_"+proportion+".txt";
        //
        this.uavs = readUAV(UAV_dir,uavNum);
        this.m= readMap(Map_dir,psNum,radius);
        this.gopack = readGoPackage(Package_dir);
        this.backpack=readBackPackage(Package_dir);
        //
        this.psnum=m.psnum;
        this.gopacknum=gopack.length;
        this.backpacknum=backpack.length;
        this.uavnum=uavs.length;
        distance=getDistance(this.m);
        //
//        this.go_packMap=new HashMap<>();
//        for(int i = 0; i < this.gopacknum; i++) {
//            this.go_packMap.put(gopack[i].id, gopack[i]);
//        }
//        this.back_packMap=new HashMap<>();
//        for(int i = 0; i < this.backpacknum; i++) {
//            this.back_packMap.put(backpack[i].id, backpack[i]);
//        }
    }
    //
    public static Map readMap(String Map_dir,int psNum,int radius){
        CenterStation cs=null;
        PostStation[] ps=new PostStation[psNum];
        String line=null;
        try {
            File file = new File(Map_dir);
            if(!file.exists()) System.out.println("Read file not found!!");
            InputStream in = new FileInputStream(file);
            InputStreamReader read = new InputStreamReader(in,"GBK");
            BufferedReader reader = new BufferedReader(read);
            if((line=reader.readLine())==null)
                System.out.println("Read cs error!!!");
            String arr[]=line.trim().split("\\s+");
            cs=new CenterStation(Integer.parseInt(String.valueOf(arr[0])),Integer.parseInt(String.valueOf(arr[1])),Integer.parseInt(String.valueOf(arr[2])));
            for(int i=0; ((line = reader.readLine())!=null); i++){
                arr=line.trim().split("\\s+");
                ps[i]=new PostStation(Integer.parseInt(String.valueOf(arr[0])),Integer.parseInt(String.valueOf(arr[1])),Integer.parseInt(String.valueOf(arr[2])));
            }
            reader.close();
        } catch(FileNotFoundException e) {
            e.printStackTrace();
        } catch(IOException e) {
            e.printStackTrace();
        }
        return new Map(psNum,radius,cs,ps);
    }

    //
    public static UAV[] readUAV(String UAV_dir,int uavNum){
        UAV[] uav=new UAV[uavNum];
        String line=null;
        try {
            File file = new File(UAV_dir);
            if(!file.exists())
                System.out.println("Read file not found!!");
            InputStream in = new FileInputStream(file);
            InputStreamReader read = new InputStreamReader(in,"GBK");
            BufferedReader reader = new BufferedReader(read);
            for(int i=0; ((line = reader.readLine())!=null); i++){
                String arr[]=line.trim().split("\\s+");
                uav[i]=new UAV(Integer.parseInt(String.valueOf(arr[0])),Integer.parseInt(String.valueOf(arr[1])),Double.parseDouble(String.valueOf(arr[2])),Integer.parseInt(String.valueOf(arr[3])));
            }
            reader.close();
        } catch(FileNotFoundException e) {
            e.printStackTrace();
        } catch(IOException e) {
            e.printStackTrace();
        }
        return uav;
    }

    //
    public static GoPackage[] readGoPackage(String Package_dir){

        GoPackage[] goPackages=new GoPackage[getgopacknum(Package_dir)];
        String line=null;
        try {
            File file = new File(Package_dir);
            InputStream in = new FileInputStream(file);
            InputStreamReader read = new InputStreamReader(in,"GBK");
            BufferedReader reader = new BufferedReader(read);
            for(int i=0; (line = reader.readLine())!=null; i++){
                String arr[]=line.trim().split("\\s+");
                if (arr[1].equals("0")){
                    goPackages[i]=new GoPackage(Integer.parseInt(String.valueOf(arr[0])),Integer.parseInt(String.valueOf(arr[1])),Integer.parseInt(String.valueOf(arr[2])),Integer.parseInt(String.valueOf(arr[3])),Integer.parseInt(String.valueOf(arr[4])));
                }
            }
            reader.close();
        } catch(FileNotFoundException e) {
            e.printStackTrace();
        } catch(IOException e) {
            e.printStackTrace();
        }
        return goPackages;
    }

    //
    public static BackPackage[] readBackPackage(String Package_dir){
        BackPackage[] backPackages=new BackPackage[getbackpacknum(Package_dir)];
        String line=null;
        try {
            File file = new File(Package_dir);
            if(!file.exists()) System.out.println("Read file not found!!");
            InputStream in = new FileInputStream(file);
            InputStreamReader read = new InputStreamReader(in,"GBK");
            BufferedReader reader = new BufferedReader(read);
            int index=0;
            for(int i=0; (line = reader.readLine())!=null; i++){
                String arr[]=line.trim().split("\\s+");
                if (arr[1].equals("1")){
                    backPackages[index]=new BackPackage(Integer.parseInt(String.valueOf(arr[0])),Integer.parseInt(String.valueOf(arr[1])),Integer.parseInt(String.valueOf(arr[2])),Integer.parseInt(String.valueOf(arr[3])),Integer.parseInt(String.valueOf(arr[4])));
                    index++;
                }
            }
            reader.close();
        } catch(FileNotFoundException e) {
            e.printStackTrace();
        } catch(IOException e) {
            e.printStackTrace();
        }
        return backPackages;
    }

    //
    public static double[][] getDistance(Map map){
        int postNumber = map.psnum;
        double[][] distance = new double[postNumber+1][postNumber+1];
        PostStation[] ps = new PostStation[postNumber+1];
        ps[0] = new PostStation(0, map.cs.x, map.cs.y);
        for(int i = 1; i <= postNumber; i++){
            ps[i] = map.ps[i-1];
        }
        for(int i = 0; i <= postNumber; i++) {
            distance[i][i] = 0.0;
            for(int j = i + 1; j <= postNumber; j++) {
                distance[i][j] = distance[j][i] = Math.sqrt(Math.pow(ps[i].x - ps[j].x,  2)+ Math.pow(ps[i].y - ps[j].y, 2));
            }
        }
        return distance;
    }

    //
    public static int getgopacknum(String Package_dir){
        int gopacknum=0;
        String line=null;
        try {
            File file = new File(Package_dir);
            InputStream in = new FileInputStream(file);
            InputStreamReader read = new InputStreamReader(in,"GBK");
            BufferedReader reader = new BufferedReader(read);
            for(int i=0; (line = reader.readLine())!=null; i++){
                String arr[]=line.trim().split("\\s+");
                if (arr[1].equals("0")){
                    gopacknum++;
                }
            }
            reader.close();
        } catch(FileNotFoundException e) {
            e.printStackTrace();
        } catch(IOException e) {
            e.printStackTrace();
        }
        return gopacknum;
    }

    //
    public static int getbackpacknum(String Package_dir){
        int backpacknum=0;
        String line=null;
        try {
            File file = new File(Package_dir);
            InputStream in = new FileInputStream(file);
            InputStreamReader read = new InputStreamReader(in,"GBK");
            BufferedReader reader = new BufferedReader(read);
            for(int i=0; (line = reader.readLine())!=null; i++){
                String arr[]=line.trim().split("\\s+");
                if (arr[1].equals("1")){
                    backpacknum++;
                }
            }
            reader.close();
        } catch(FileNotFoundException e) {
            e.printStackTrace();
        } catch(IOException e) {
            e.printStackTrace();
        }
        return backpacknum;
    }

//    public static void main(String[] args) {
//        InstanceFetcher ins= new InstanceFetcher(1000,10,500000,0.2,10,0);
//        System.out.println(ins.gopacknum);
//        System.out.println(ins.backpacknum);
//        System.out.println(ins.uavnum);
//        System.out.println(ins.psnum);
//    }
}

