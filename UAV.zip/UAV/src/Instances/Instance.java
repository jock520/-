//package Instances;

///**
// * @author ：cavan
// * @date ：2019/5/6 18:56
// */
//public class Instance {
//    public Instance(String Map_dir,String UAV_dir,String Package_dir) {
////        go_packMap=new HashMap<>();
////        for(int i = 0; i < gopacknum; i++) {
////            go_packMap.put(gopack[i].id, gopack[i]);
////        }
////        back_packMap=new HashMap<>();
////        for(int i = 0; i < backpacknum; i++) {
////            back_packMap.put(backpack[i].id, backpack[i]);
////        }
//    }
//}
