package Instances;

import Resource.UAV.UAV;
import Tool.textWriter;
import static Instances.Parameters.*;

/**
 * @author ：cavan
 * @date ：2019/4/17 22:28
 */
public class UAVGenerator {
    public UAV[] uav;
    public int[] uavWeightlimit={4000,6000,8000};
    public double[] uavAvgSpeed={1500,1000,600};
    public int[] uavFlyingTime={25,20,15};
    String str;
    public UAVGenerator( String dir,int uavNum, int type){
//    public UAVGenerator(int uavNum, int type){
        uav=new UAV[uavNum];
        for(int i=0; i<uavNum; i++) {
            uav[i]=new UAV(i+1,uavWeightlimit[type],uavAvgSpeed[type],uavFlyingTime[type]);
        }
        str=new String();
        for(int i=0; i<uavNum; i++) {
            str=str+uav[i].uavId+"\t"+uav[i].weightlimit+"\t"+uav[i].avgSpeed+"\t"+uav[i].flyingTime+"\r\n";
        }
        new textWriter(dir,str);
    }
//    public static void main(String[] args) {
//        for (int i=0;i<uavNum.length;i++){
//            for (int j = 0; j<uavType.length; j++){
//                String dir="instance/UAV/" + "UAV_" + uavNum[i] + "_" + uavType[j] +".txt";
//                new UAVGenerator(dir,uavNum[i],uavType[j]);
////                new UAVGenerator(uavNum[i],uavType[j]);
//            }
//        }
//    }
}
