package Instances;

import static Instances.Parameters.*;
/**
 * @author ：cavan
 * @date ：2019/4/17 21:04
 */
public class InstanceGenerator {
    //生成测试实例，保存到txt文件中
    public InstanceGenerator(){
        for (int i=0;i<radius.length;i++){
            for (int j = 0; j< psNum.length; j++){
                for (int k=0;k<10;k++) {
                    String dir = "instance/Map/" + "Map_" + radius[i] + "_" + psNum[j] + "_"+k+".txt";
                    new MapGenerator(dir, radius[i], psNum[j]);
                }
            }
        }
        for (int i=0;i<psNum.length;i++){
            for (int j=0;j<weight.length;j++){
                for (int m=0;m<proportion.length;m++){
                    for (int k=0;k<10;k++) {
                        String dir = "instance/Packages/" + "Package_" + psNum[i] + "_" + weight[j] + "_"+proportion[m]+"_"+k+".txt";
                        new PackageGenerator(dir,psNum[i],weight[j],proportion[m]);
                    }
                }
            }
        }
//        for (int i=0;i<uavNum.length;i++){
//            for (int j = 0; j<uavType.length; j++){
//                new UAVGenerator(uavNum[i],uavType[j]);
//            }
//        }
    }
//    public static void main(String[] args) {
//        InstanceGenerator ig=new InstanceGenerator();
//    }
}
