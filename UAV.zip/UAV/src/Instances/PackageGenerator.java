package Instances;

import java.util.Random;
import java.lang.Math;
import Resource.Package.BackPackage;
import Resource.Package.GoPackage;
import Tool.textWriter;
import static Instances.Parameters.*;
/**
 * @author ：cavan
 * @date ：2019/4/17 20:20
 */
public class PackageGenerator {
    public int goPackNum;
    public int backPackNum;
    public GoPackage[] gp;
    public BackPackage[] bp;
    private String str;
    //s：用例文档的输出位置。	MyM：一个有内容的Map对象     sWeight所有包裹的总重量。
    public PackageGenerator(String dir,int psNum,int sWeight,double proportion) {
        //依次产生随机的包裹，直到产生包裹的总重量大于上限为止。
        gp =new GoPackage[8000];
        int goWeight=0;
        this.goPackNum =0;
        while (goWeight<=sWeight) {
            int id=this.goPackNum +1;
            int weight=50*(new Random().nextInt(38)+2);
            int state=0;
            int destination=new Random().nextInt(psNum)+1;
            int random=(int)(Math.random()*10+1);
            int vip;
            if (random<3) {
                vip = 2;//控制20%的紧急度为参数2
            } else if (random<6){
                vip=5;//控制30%的紧急度为参数5
            }else {
                vip=10;//控制50%的紧急度为参数10
            }
            gp[this.goPackNum]=new GoPackage(id,state,weight,vip,destination);
            goWeight+= weight;
            this.goPackNum++;
        }
        this.goPackNum--;
        bp=new BackPackage[8000];
        this.backPackNum=0;
        int backWeight=0;
        while (backWeight<=proportion*sWeight) {
            int id=this.backPackNum+1;
            int weight=50*(new Random().nextInt(38)+2);
            int state=1;
            int vip=0;//返回时的紧急度为参数0
            int destination=new Random().nextInt(psNum)+1;
            bp[this.backPackNum]=new BackPackage(id,state,weight,vip,destination);
            backWeight=backWeight+ gp[this.backPackNum].weight;
            this.backPackNum++;
        }
        backPackNum--;
        str=new String();
        for(int i = 0; i<this.goPackNum; i++) {
            str=str+ gp[i].id+"\t"+gp[i].state+"\t"+ gp[i].weight+"\t"+ gp[i].vip+"\t"+ gp[i].destination+"\r\n";
        }
        for(int i=0;i<this.backPackNum;i++){
            str=str+bp[i].id+"\t"+bp[i].state+"\t"+ bp[i].weight+"\t"+ bp[i].vip+"\t"+ bp[i].destination+"\r\n";
        }
        new textWriter(dir,str);
    }

//    public static void main(String args[]) {
//        for (int i=0;i<psNum.length;i++){
//            for (int j=0;j<weight.length;j++){
//                for (int m=0;m<proportion.length;m++){
//                    String dir = "instance/Packages/" + "Package_" + psNum[i] + "_" + weight[j] + "_"+proportion[m]+".txt";
//                    new PackageGenerator(dir,psNum[i],weight[j],proportion[m]);
//                }
//            }
//        }
//    }
}

