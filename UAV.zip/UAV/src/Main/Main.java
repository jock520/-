//package Main;
//
//import Instances.InstanceFetcher;
//
//import static Instances.Parameters.*;
//
///**
// * @author ：cavan
// * @date ：2019/4/26 18:51
// */
//public class Main {
//    public static void main(String[] args) {
//        String Map_dir="instance/Map/" + "Map_" + radius[0] + "_" + psNum[0] + "_"+0+".txt";
//        String Package_dir="instance/Packages/" + "Package_" + psNum[0] + "_" + weight[0] + "_"+proportion[0]+"_"+0+".txt";
//        InstanceFetcher inf=new InstanceFetcher(Map_dir,Package_dir,uavNum[0],uavType[0]);
//        System.out.println(inf.psNum);
//    }
////    public static void main(String[] args) {
////        for (int i=0;i<radius.length;i++) {
////            for (int j = 0; j < psNum.length; j++) {
////                for (int l = 0; l < weight.length; l++) {
////                    for (int m = 0; m < proportion.length; m++) {
////                        for (int n = 0; n < uavNum.length; n++) {
////                            for (int h = 0; h < uavType.length; h++) {
////                                for (int b = 0; b < 10; b++) {
////                                    String Map_dir="instance/Map/" + "Map_" + radius[i] + "_" + psNum[j] + "_"+b+".txt";
////                                    String Package_dir="instance/Packages/" + "Package_" + psNum[j] + "_" + weight[l] + "_"+proportion[m]+"_"+b+".txt";
////                                    InstanceFetcher mif=new InstanceFetcher(Map_dir,Package_dir,uavNum[n],uavType[h]);
////
////                                }
////                            }
////                        }
////                    }
////                }
////            }
////        }
////    }
//}
