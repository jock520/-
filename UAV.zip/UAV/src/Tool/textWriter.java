package Tool;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class textWriter {
    //dir文件目录，str写入的字符
    public  textWriter(String dir,String str) {
        try {
            File file=new File(dir);
            if(!file.exists())
                file.createNewFile();
            FileOutputStream fos=new FileOutputStream(file);
            fos.write(str.getBytes());
            fos.flush();
            fos.close();
        }
        catch(FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }
}
