package Tool;

import java.io.*;
/**
 * @author ：cavan
 * @date ：2019/4/18 14:36
 */
public class textReader {
    public textReader(String dir){
        String line=null;
        try{
            File file = new File(dir);
            if(!file.exists()){
                System.out.println("Read file not found!!");
            }
            InputStream in = new FileInputStream(file);
            InputStreamReader read = new InputStreamReader(in,"GBK");
            BufferedReader reader = new BufferedReader(read);
            if((line=reader.readLine())==null){
                System.out.println("Read cs error!!!");
            }
//            reader.readLine();
            while ((line = reader.readLine())!=null){
                System.out.println(line);
            }
            reader.close();
        }catch(FileNotFoundException e) {
            e.printStackTrace();
        }catch(IOException e) {
            e.printStackTrace();
        }
    }
}
