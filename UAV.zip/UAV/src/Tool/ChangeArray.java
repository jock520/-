//package Tool;
//
//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.HashMap;
//import java.util.TreeMap;
//import Instances.InstanceFetcher;
//import Resource.Package.Package;
//
//
//public class ChangeArray {
//	public InstanceFetcher ins;
//
//	public HashMap<Integer, TreeMap<Integer, ArrayList<Integer>>> array;
//	public HashMap<Integer, TreeMap<Integer, ArrayList<Integer>>> arrayTemp;
//
//	public TreeMap<Integer, ArrayList<Integer>> packs;
//	public TreeMap<Integer, ArrayList<Integer>> packsTemp;
//
//	public ArrayList<ArrayList<Integer>> noOrderPacks;
//	public ArrayList<ArrayList<Integer>> noOrderPacksTemp;
//
//	public ChangeArray(InstanceFetcher ins,HashMap<Integer, TreeMap<Integer, ArrayList<Integer>>> array, TreeMap<Integer, ArrayList<Integer>> packs) {
//		this.packs = clonePacks(packs);
//		this.array = cloneArray(array);
//		this.ins = ins;
//	}
//	//交换两个
//	public void changeOne() {
//		save();
//		//T[]类型 Set.toArray(T[] a)
//		//返回一个包含此集合中所有元素的数组; 返回的数组的运行时类型是指定数组的运行时类型。
//		Integer[] keys=array.keySet().toArray(new Integer[]{});//keySet()返回地图中包含的键Set类型
//		int rad1 = (int)(Math.floor(Math.random() * ins.psNum + 1));
//		for (Integer key:keys){
//			if (key==rad1){
//				TreeMap<Integer, ArrayList<Integer>> pack = array.get(key);
//				int length=pack.size();
//				int rad2 = (int)Math.floor(Math.random() * length);//随机产生交换的包裹的id
//				int rad3= (int)Math.floor(Math.random() * length);
//				if (length==2){
//					rad2=0;
//				}
//				if(length == 0 || length == 1) {
//					break;	// break, there is no need to change
//				}
//				while(rad2 == rad3) {//如果相同，产生新位置
//					rad3 = (int)Math.floor(Math.random() * length);
//				}
//				int number1 = pack.get(rad2).size();
//				int number2 = pack.get(rad3).size();
//				// choose two packages
//				int rad4 = (int)Math.floor(Math.random() * number1);
//				int rad5 = (int)Math.floor(Math.random() * number2);
//				// exchange them// rad2 - rad4// rad3 - rad5
//				Integer temp = pack.get(rad2).get(rad4);
//				pack.get(rad2).set(rad4, pack.get(rad3).get(rad5) );
//				pack.get(rad3).set(rad5, temp);
//				neaten(key);
//			}
//		}
//		recalculatePacks();
//	}
//
//	public  void neaten(Integer key){
//		ArrayList<Integer> queue = transfer(key);
//		int uavWeight = ins.uavs[ins.uavType].weightlimit;
//		int currentWeight = 0;
//		int times = 0;
//		ArrayList<Integer> onePack = new ArrayList<Integer>();
//		// clear array.get(key)
//		array.get(key).clear();
//		for(int i = 0; i < queue.size(); i++) {
//			Package p = ins.go_packMap.get(queue.get(i));
//			currentWeight += p.Weight;
//			onePack.add(((Package) p).goPackNum);
//			if(currentWeight > uavWeight) {
//				onePack.remove(onePack.size() - 1);
//				array.get(key).put(times, onePack);
//				// update
//				times++;
//				onePack = new ArrayList<Integer>();
//				onePack.add(p.goPackNum);
//				currentWeight = p.Weight;
//			}
//		}
//		// check is all packs
//		if(onePack.size() != 0) {
//			array.get(key).put(times, onePack);
//		}
//	}
//
//	public ArrayList<Integer> transfer(Integer index) {
//		ArrayList<Integer> res = new ArrayList<Integer>();
//		TreeMap<Integer, ArrayList<Integer>> pack = array.get(index);
//		Integer[] keys = pack.keySet().toArray(new Integer[] {});
//		for(Integer key : keys)
//			res.addAll(pack.get(key));
//		return res;
//	}
//
//	public void recalculatePacks() {
//		// clear packs in order to rebulid it
//		packs.clear();
//		Integer[] keys = array.keySet().toArray(new Integer[] {});
//		for(Integer key : keys) {
//			TreeMap<Integer, ArrayList<Integer>> pack = array.get(key);
//			Integer[] times = pack.keySet().toArray(new Integer[] {});
//			for(Integer time : times) {
//				ArrayList<Integer> onePack = pack.get(time);
//				double t = 0.0;
//				for(int i = 0; i < onePack.size(); i++) {
////					t += ins.packageMap.get(onePack.get(i)).342424);
//				}
//				while(packs.get((int)t) != null) {
//					t++;
//				}
//				packs.put((int)t, onePack);
//			}
//		}
//	}
//
//	public void save() {
//		arrayTemp = cloneArray(array);
//		packsTemp = clonePacks(packs);
//	}
//
//	public void rollback() {
//		array = arrayTemp;
//		packs = packsTemp;
//	}
//
//	//复制一遍
//	public HashMap<Integer, TreeMap<Integer, ArrayList<Integer>>> cloneArray(HashMap<Integer, TreeMap<Integer, ArrayList<Integer>>> source){
//		HashMap<Integer, TreeMap<Integer, ArrayList<Integer>>> res = new HashMap<Integer, TreeMap<Integer, ArrayList<Integer>>>();
//
//		Integer[] keys = source.keySet().toArray(new Integer[] {});
//		for(Integer key : keys) {
//			TreeMap<Integer, ArrayList<Integer>> pack = source.get(key);
//			TreeMap<Integer, ArrayList<Integer>> newPack = new TreeMap<Integer, ArrayList<Integer>>();
//			Integer[] times = pack.keySet().toArray(new Integer[] {});
//			for(Integer time : times)
//				newPack.put(time, (ArrayList<Integer>)pack.get(time).clone());//Obj.clone()返回此实例的浅拷贝
//			res.put(key, newPack);
//		}
//		return res;
//	}
//
//	//ImprovedSA    //将复制一次
//	public static TreeMap<Integer, ArrayList<Integer>> clonePacks(TreeMap<Integer, ArrayList<Integer>> source) {
//		TreeMap<Integer, ArrayList<Integer>> res = new TreeMap<Integer, ArrayList<Integer>>();
//
//		Integer[] keys = source.keySet().toArray(new Integer[] {});
//		for(Integer key : keys)
//			res.put(key, (ArrayList<Integer>)source.get(key).clone());
//		return res;
//	}
//
//	//noOrderPacks没有排序的Packages
//	public void savePacks() {
//		noOrderPacksTemp = cloneNoOrderPacks();
//	}
//	//ImprovedSA
//	public void rollbackPacks() {
//		noOrderPacks = noOrderPacksTemp;
//	}
//
//	public ArrayList<ArrayList<Integer>> cloneNoOrderPacks() {
//		ArrayList<ArrayList<Integer>> res = new ArrayList<ArrayList<Integer>>();
//		for(int i = 0; i < noOrderPacks.size(); i++)
//			res.add((ArrayList<Integer>)noOrderPacks.get(i).clone());
//		return res;
//	}
//
//	public void changeNoOrderPacks() {
//		// save
//		savePacks();
//
//		int length = noOrderPacks.size();
//		int rad1 = (int)Math.floor(Math.random() * (length - 1));
//		int rad2 = 0;
//		double r = Math.random();
//		if(r < 0.1) {
//			rad2 = (int)Math.floor(Math.random() * length);
//			while(rad1 == rad2) {
//				rad2 = (int)Math.floor(Math.random() * length);
//			}
//		} else {
//			rad2 = rad1 + 1;
//		}
//
//		Collections.swap(noOrderPacks, rad1, rad2);
//	}
//
//	//ImprovedSA
//	public void preparePackChange() {
//		noOrderPacks = new ArrayList<ArrayList<Integer>>();
//		Integer[] keys = packs.keySet().toArray(new Integer[] {});
//		for(Integer key : keys) {
//			ArrayList<Integer> onePack = packs.get(key);
//			ArrayList<Integer> onePackTemp = (ArrayList<Integer>)onePack.clone();
//			noOrderPacks.add(onePackTemp);
//		}
//	}
//
//}
//
//
//
//
//
//
//
//
//
//
//
