package Resource.Package;

/**
 * @author ：cavan
 * @date ：2019/5/5 10:46
 */
public class GoPackage extends Package{
    public GoPackage(int id, int state,int weight, int vip,int destination) {
        super(id, state, weight, vip, destination);
    }
}
