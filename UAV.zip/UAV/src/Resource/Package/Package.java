package Resource.Package;

public class Package {

	public int id;
	public int state;
	public int weight;
	public long vip;//分为3等级，参数2，5，10
	public int destination;

	public Package(int id, int state,int weight, int vip,int destination) {
		this.id= id;
		this.state=state;
		this.weight = weight;
		this.vip = vip;
		this.destination= destination;
	}

	@Override
	public String toString() {//写入txt 格式
		String res =id + "\t" + weight + "\t" + vip+"\t"+destination + "\r\n";
		return res;
	}

}
