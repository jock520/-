package Resource.UAV;

public class UAV {
    public int uavId;
    public int weightlimit;
    public double avgSpeed;
    public int flyingTime;

    public UAV(int uavId,int weightlimit,double avgSpeed,int flyingTime){
        this.uavId=uavId;
        this.weightlimit=weightlimit;
        this.avgSpeed=avgSpeed;
        this.flyingTime=flyingTime;
    }
}
