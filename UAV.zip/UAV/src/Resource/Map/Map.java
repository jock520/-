package Resource.Map;

public class Map {
	public int radius;//	public int[] Radius={1000,2500,5000};	//单位：米
	public int psnum;//	public int[] psNum={10,20,30};//个
	public CenterStation cs;
	public PostStation[] ps;

	public Map(int psnum,int radius,CenterStation cs, PostStation[] ps){
		this.psnum=psnum;
		this.radius=radius;
		this.cs=cs;
		this.ps=ps;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(cs.id + "\t" + cs.x + "\t" + cs.y + "\r\n");
		for(int i = 0; i < ps.length; i++) {
			builder.append(ps[i].id + "\t" + ps[i].x + "\t" + ps[i].y + "\r\n");
		}
		return builder.toString();
	}

//	public static void main(String[] args) {
//		Map m=new Map(1000,10);
//		for (int i=0;i<10;i++){
//			System.out.print(m.ps[i].stationId+"	");
//			System.out.print(m.ps[i].x+"	");
//			System.out.println(m.ps[i].y);
//		}
//	}
}
