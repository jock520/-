package Resource.Map;

public class CenterStation extends Station {

    public CenterStation(int id, int x, int y) {
        super(id, x, y);
    }
}
