package Resource.Map;

/**
 * @author ：cavan
 * @date ：2019/5/5 10:43
 */
public class Station {
    public int id;
    public int x;
    public int y;

    public Station(int id, int x, int y) {
        this.id = id;
        this.x = x;
        this.y = y;
    }
}
