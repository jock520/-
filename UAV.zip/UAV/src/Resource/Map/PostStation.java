package Resource.Map;

import Resource.Map.Station;

public class PostStation extends Station {

	public PostStation(int id, int x, int y) {
		super(id, x, y);
	}
}
