//package Algorithm;
//
//import Instances.InstanceFetcher;
//import Tool.ChangeArray;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.TreeMap;
//
///**
// * @author ：cavan
// * @date ：2019/4/28 13:37
// */
//public class LocalSearchAlgorithm extends Algorithm {
//
//    public LocalSearchAlgorithm(InstanceFetcher inf,  HashMap<Integer, TreeMap<Integer, ArrayList<Integer>>> array, TreeMap<Integer, ArrayList<Integer>> packs) {
//        super("SA");
//        double s1, s2;
//        ChangeArray obj = new ChangeArray(inf, array, packs);
//        start = Fitness.Fitness(obj.packs,inf);
//
//        startTime = System.currentTimeMillis();
//        s1 = start;
//        s2 = 0.0;
//
//        double T = 10000;//系统的温度，系统初始应该要处于一个高温的状态
//        double r = 0.9999;	//  用于控制降温的快慢
//        int times = 1;
//        while(T > 100) {//100为温度的下限，若温度T达到T_min，则停止搜索
//            obj.changeOne();
//            s2 = Fitness.Fitness(obj.packs,inf);
//            if(s2 >= s1) {
//                s1 = s2;
//            } else {
//                obj.rollback();
//            }
//            times++;
//            T *= r;//r越大，降温越慢；r越小，降温越快
//        }
//        end =Fitness.Fitness(obj.packs,inf);
//
//        endTime = System.currentTimeMillis();
//        costTime = endTime - startTime;
//    }
//}
