package Algorithm;

/**
 * @author ：cavan
 * @date ：2019/4/28 13:07
 */
public class Algorithm {
    public String way;
    public long startTime;//startTime = System.currentTimeMillis();
    public long endTime;//endTime = System.currentTimeMillis();
    public long costTime;//程序执行时间costTime=startTime-endTime

    public double start;//Fitness.Fitness(s,inf);优化目标的值
    public double end;//Fitness.Fitness(s,inf);
    public Algorithm(String way) {
        this.way = way;
    }
}
