package Algorithm;


import Instances.InstanceFetcher;
import Resource.Package.GoPackage;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author ：cavan
 * @date ：2019/4/26 13:31
 */
public class InitialGeneration {
    //Integer 包裹的ID，打包包裹的集合

    public static HashMap<Integer, ArrayList<ArrayList<Integer>>> array;
    public static ArrayList<ArrayList<Integer>> packs;
    //包裹的
    public InitialGeneration(InstanceFetcher ins){

        GoPackage[] goPackages=ins.gopack;
        int gopacknum=ins.gopacknum;
        int psnum=ins.psnum;
        int uavweight=ins.uavs[0].weightlimit;

        //初始化
        array= new HashMap<>();
        packs=new ArrayList<>();

        int packnum=0;
        int index=1;
        Integer[] keys=null;
        //随机打包；
        while (packnum!=ins.gopacknum){
            ArrayList<Integer> bigpack=new ArrayList<>();
            if (goPackages[packnum].destination==index){
                bigpack.add(goPackages[0].id);
                packs.add(bigpack);
                packnum++;
                bigpack.clear();
                array.put(index,packs);
            }
            index++;
        }
    }

    public static void main(String[] args) {

        InstanceFetcher ins= new InstanceFetcher(1000,10,500000,0.2,10,0);
        //

//        Integer[] keys=array.keySet().toArray(new Integer[]{});
        //HashMap<Integer, ArrayList<ArrayList<Integer>>> array;
//        for (Integer key:keys){
//            ArrayList<ArrayList<Integer>> bigpack=array.get(key);
//            for (int i=0;i<bigpack.size();i++){
//                ArrayList<Integer> pack=bigpack.get(i);
//                System.out.print("[");
//                for (Integer j:pack){
//                    System.out.print(j);
//                }
//                System.out.print("]");
//            }
//        }
    }

}
