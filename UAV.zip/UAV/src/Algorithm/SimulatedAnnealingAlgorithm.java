//package Algorithm;
//
//import Instances.InstanceFetcher;
//import Solution.Schedule;
//import Tool.ChangeArray;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.TreeMap;
//
///**
// * @author ：cavan
// * @date ：2019/4/28 14:13
// */
//public class SimulatedAnnealingAlgorithm extends Algorithm {
//    public double best_S;
//
//    public SimulatedAnnealingAlgorithm(InstanceFetcher inf, HashMap<Integer, TreeMap<Integer, ArrayList<Integer>>> array, TreeMap<Integer, ArrayList<Integer>> packs) {
//        super("SimulatedAnnealingAlgorithm");
//        double s1, s2;
//        ChangeArray obj = new ChangeArray(inf, array, packs);
//        start = Fitness.Fitness(obj.packs, inf);
//        startTime = System.currentTimeMillis();
//        s1 = start;
//        s2 = 0.0;
//
//        double T = 10000;//系统的温度，系统初始应该要处于一个高温的状态
//        double r = 0.9999;    //  用于控制降温的快慢
//        int times = 1;
//        best_S = s1;
//
//        while (T > 100) {//100为温度的下限，若温度T达到T_min，则停止搜索
//            obj.changeOne();
//            s2 = Fitness.Fitness(obj.packs, inf);
//            if (s2 > s1) {
//                // 更新解
//                s1 = s2;
//                if (s1 > best_S) {
//                    best_S = s1;// 保存全局最优解
//                }
//            } else {
//                double p = Math.exp((s2 - best_S) / (best_S / times / 10));
//                double rad = Math.random();
//                if (rad > p) {
//                    obj.rollback();//扰动
//                } else {
//                    // 更新解，但不保存
//                    s1 = s2;
//                }
//            }
//            times++;
//            T *= r;//r越大，降温越慢；r越小，降温越快
//        }
//        end = s1;
//        endTime = System.currentTimeMillis();
//        costTime = endTime - startTime;
//    }
//}