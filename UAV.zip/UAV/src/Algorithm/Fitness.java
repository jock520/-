//package Algorithm;
//
//import Instances.InstanceFetcher;
//import Resource.Package.Package;
//import java.util.ArrayList;
//import java.util.TreeMap;
//
///**
// * @author ：cavan
// * @date ：2019/4/28 13:22
// */
//public class Fitness {
//    public static double CSTime=5.00;
//    public static double PSTime=3.00;
//    //计算优化目标的值，优化总完成时间
//    //排序后的用这个
//    public static double Fitness(TreeMap<Integer, ArrayList<Integer>> packs, InstanceFetcher ins) {
//        double res = 0.0;
//        int t1 = 0;
//        int t2 = 0;
//        double[] time=new double[ins.UavNum];
//        for (int i=0;i<ins.UavNum;i++){
//            time[i]=0.0;
//        }
//        //无人机的key值，
//        Integer[] keys=packs.keySet().toArray(new Integer[]{});
//        int index=0;//用于选取哪台无人机
//        for(Integer key : keys) {
//            //
//            ArrayList<Integer> onePack = packs.get(key);
//            Package first = ins.go_packMap.get(onePack.get(0));
//            time[index] += CSTime+2 * ins.m.matrix[0][first.StationID] / ins.uavs[ins.uavType].avgSpeed+PSTime;
//            for(int i = 0; i < onePack.size(); i++) {
//                Package p = ins.go_packMap.get(onePack.get(i));
//                t1  +=ins.pack[i].StationID;
//                t2  +=ins.pack[i+1].StationID;
//                if(t1!=t2){
//                    time[i]+=((double)ins.m.matrix[t1][t2])/ins.uavs[ins.uavType].avgSpeed +PSTime;
//                }
//            }
//            time[index] +=  ins.m.matrix[0][first.StationID] / ins.uavs[ins.uavType].avgSpeed;
//            index = (index+1) % ins.UavNum;
//        }
//        return res;
//    }
//
//    //无序的用这个
//    public static double Fitness(ArrayList<ArrayList<Integer>> noOrderPacks, InstanceFetcher ins) {
//        double res = 0.0;
//        double t1 = 0.0;
//        double t2 = 0.0;
//
//        return res;
//    }
//
//}
